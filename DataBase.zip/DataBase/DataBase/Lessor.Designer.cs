﻿
namespace DataBase
{
    partial class Lessor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.Report = new System.Windows.Forms.Button();
            this.Choose_Vehicle = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.lbldetails = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Picture = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Cost = new System.Windows.Forms.Label();
            this.Type_Vehicle = new System.Windows.Forms.Label();
            this.comcost = new System.Windows.Forms.ComboBox();
            this.comtyper = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtvno = new System.Windows.Forms.TextBox();
            this.txttitle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtorderno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtinfo = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtloc = new System.Windows.Forms.TextBox();
            this.txtcost = new System.Windows.Forms.TextBox();
            this.txtyear = new System.Windows.Forms.TextBox();
            this.txtlno = new System.Windows.Forms.TextBox();
            this.txtmodel = new System.Windows.Forms.TextBox();
            this.btnprogress = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtdur = new System.Windows.Forms.TextBox();
            this.btnLess = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.Report);
            this.panel1.Controls.Add(this.Choose_Vehicle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(306, 668);
            this.panel1.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(65, 274);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(153, 45);
            this.button6.TabIndex = 2;
            this.button6.Text = "Log Out";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Report
            // 
            this.Report.Location = new System.Drawing.Point(65, 161);
            this.Report.Name = "Report";
            this.Report.Size = new System.Drawing.Size(153, 51);
            this.Report.TabIndex = 1;
            this.Report.Text = "Report";
            this.Report.UseVisualStyleBackColor = true;
            this.Report.Click += new System.EventHandler(this.Report_Click);
            // 
            // Choose_Vehicle
            // 
            this.Choose_Vehicle.Location = new System.Drawing.Point(65, 48);
            this.Choose_Vehicle.Name = "Choose_Vehicle";
            this.Choose_Vehicle.Size = new System.Drawing.Size(153, 49);
            this.Choose_Vehicle.TabIndex = 0;
            this.Choose_Vehicle.Text = "Choose Vehicle";
            this.Choose_Vehicle.UseVisualStyleBackColor = true;
            this.Choose_Vehicle.Click += new System.EventHandler(this.Choose_Vehicle_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.btnok);
            this.panel2.Controls.Add(this.lbldetails);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.Picture);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Cost);
            this.panel2.Controls.Add(this.Type_Vehicle);
            this.panel2.Controls.Add(this.comcost);
            this.panel2.Controls.Add(this.comtyper);
            this.panel2.Location = new System.Drawing.Point(306, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1059, 668);
            this.panel2.TabIndex = 1;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(824, 99);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(110, 34);
            this.button5.TabIndex = 10;
            this.button5.Text = "Choose";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.DarkCyan;
            this.btnok.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnok.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnok.Location = new System.Drawing.Point(917, 607);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(111, 41);
            this.btnok.TabIndex = 9;
            this.btnok.Text = "OK";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // lbldetails
            // 
            this.lbldetails.AutoSize = true;
            this.lbldetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldetails.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbldetails.Location = new System.Drawing.Point(616, 187);
            this.lbldetails.Name = "lbldetails";
            this.lbldetails.Size = new System.Drawing.Size(0, 25);
            this.lbldetails.TabIndex = 8;
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(62, 347);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 34);
            this.button3.TabIndex = 7;
            this.button3.Text = "Previous";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(478, 347);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 34);
            this.button2.TabIndex = 6;
            this.button2.Text = "Next";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Picture
            // 
            this.Picture.AutoSize = true;
            this.Picture.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Picture.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Picture.Location = new System.Drawing.Point(187, 187);
            this.Picture.Name = "Picture";
            this.Picture.Size = new System.Drawing.Size(269, 25);
            this.Picture.TabIndex = 5;
            this.Picture.Text = "Select The Vehicle You Want";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(192, 220);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(263, 190);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Cost
            // 
            this.Cost.AutoSize = true;
            this.Cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cost.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Cost.Location = new System.Drawing.Point(419, 102);
            this.Cost.Name = "Cost";
            this.Cost.Size = new System.Drawing.Size(53, 25);
            this.Cost.TabIndex = 3;
            this.Cost.Text = "Cost";
            // 
            // Type_Vehicle
            // 
            this.Type_Vehicle.AutoSize = true;
            this.Type_Vehicle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Type_Vehicle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Type_Vehicle.Location = new System.Drawing.Point(39, 101);
            this.Type_Vehicle.Name = "Type_Vehicle";
            this.Type_Vehicle.Size = new System.Drawing.Size(133, 25);
            this.Type_Vehicle.TabIndex = 2;
            this.Type_Vehicle.Text = "Type_Vehicle";
            // 
            // comcost
            // 
            this.comcost.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comcost.FormattingEnabled = true;
            this.comcost.Location = new System.Drawing.Point(478, 101);
            this.comcost.Name = "comcost";
            this.comcost.Size = new System.Drawing.Size(289, 24);
            this.comcost.TabIndex = 1;
            // 
            // comtyper
            // 
            this.comtyper.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comtyper.FormattingEnabled = true;
            this.comtyper.Items.AddRange(new object[] {
            "Car",
            "Motorcycle",
            "Ship"});
            this.comtyper.Location = new System.Drawing.Point(208, 102);
            this.comtyper.Name = "comtyper";
            this.comtyper.Size = new System.Drawing.Size(138, 24);
            this.comtyper.TabIndex = 0;
            this.comtyper.SelectedIndexChanged += new System.EventHandler(this.comtyper_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.txtvno);
            this.panel3.Controls.Add(this.txttitle);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txtorderno);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.txtinfo);
            this.panel3.Location = new System.Drawing.Point(306, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1059, 668);
            this.panel3.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Vehicle No :";
            // 
            // txtvno
            // 
            this.txtvno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvno.Location = new System.Drawing.Point(148, 81);
            this.txtvno.Name = "txtvno";
            this.txtvno.Size = new System.Drawing.Size(198, 30);
            this.txtvno.TabIndex = 7;
            // 
            // txttitle
            // 
            this.txttitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttitle.ForeColor = System.Drawing.Color.Silver;
            this.txttitle.Location = new System.Drawing.Point(636, 45);
            this.txttitle.Name = "txttitle";
            this.txttitle.Size = new System.Drawing.Size(328, 30);
            this.txttitle.TabIndex = 6;
            this.txttitle.Text = "Not more than 15 characters";
            this.txttitle.TextChanged += new System.EventHandler(this.txttitle_TextChanged);
            this.txttitle.Enter += new System.EventHandler(this.txttitle_Enter);
            this.txttitle.Leave += new System.EventHandler(this.txttitle_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(356, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(260, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Main Reason For Complain :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Order No :";
            // 
            // txtorderno
            // 
            this.txtorderno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtorderno.Location = new System.Drawing.Point(133, 45);
            this.txtorderno.Name = "txtorderno";
            this.txtorderno.Size = new System.Drawing.Size(213, 30);
            this.txtorderno.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 142);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Add Any Other Information :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(895, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 49);
            this.button1.TabIndex = 1;
            this.button1.Text = "Send My Report";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtinfo
            // 
            this.txtinfo.Location = new System.Drawing.Point(6, 177);
            this.txtinfo.Multiline = true;
            this.txtinfo.Name = "txtinfo";
            this.txtinfo.Size = new System.Drawing.Size(1053, 491);
            this.txtinfo.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.panel4.Controls.Add(this.pictureBox2);
            this.panel4.Controls.Add(this.txtloc);
            this.panel4.Controls.Add(this.txtcost);
            this.panel4.Controls.Add(this.txtyear);
            this.panel4.Controls.Add(this.txtlno);
            this.panel4.Controls.Add(this.txtmodel);
            this.panel4.Controls.Add(this.btnprogress);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(285, -13);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1096, 729);
            this.panel4.TabIndex = 11;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(692, 121);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(357, 289);
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            // 
            // txtloc
            // 
            this.txtloc.Enabled = false;
            this.txtloc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtloc.Location = new System.Drawing.Point(131, 369);
            this.txtloc.Name = "txtloc";
            this.txtloc.Size = new System.Drawing.Size(435, 30);
            this.txtloc.TabIndex = 24;
            // 
            // txtcost
            // 
            this.txtcost.Enabled = false;
            this.txtcost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcost.Location = new System.Drawing.Point(173, 304);
            this.txtcost.Name = "txtcost";
            this.txtcost.Size = new System.Drawing.Size(393, 30);
            this.txtcost.TabIndex = 23;
            // 
            // txtyear
            // 
            this.txtyear.Enabled = false;
            this.txtyear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtyear.Location = new System.Drawing.Point(216, 242);
            this.txtyear.Name = "txtyear";
            this.txtyear.Size = new System.Drawing.Size(350, 30);
            this.txtyear.TabIndex = 22;
            // 
            // txtlno
            // 
            this.txtlno.Enabled = false;
            this.txtlno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlno.Location = new System.Drawing.Point(199, 180);
            this.txtlno.Name = "txtlno";
            this.txtlno.Size = new System.Drawing.Size(367, 30);
            this.txtlno.TabIndex = 21;
            // 
            // txtmodel
            // 
            this.txtmodel.Enabled = false;
            this.txtmodel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmodel.Location = new System.Drawing.Point(110, 118);
            this.txtmodel.Name = "txtmodel";
            this.txtmodel.Size = new System.Drawing.Size(456, 30);
            this.txtmodel.TabIndex = 20;
            // 
            // btnprogress
            // 
            this.btnprogress.BackColor = System.Drawing.Color.DarkCyan;
            this.btnprogress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprogress.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnprogress.Location = new System.Drawing.Point(938, 620);
            this.btnprogress.Name = "btnprogress";
            this.btnprogress.Size = new System.Drawing.Size(111, 41);
            this.btnprogress.TabIndex = 19;
            this.btnprogress.Text = "Progress";
            this.btnprogress.UseVisualStyleBackColor = false;
            this.btnprogress.Click += new System.EventHandler(this.btnprogress_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 25);
            this.label10.TabIndex = 18;
            this.label10.Text = "Location :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(28, 307);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 25);
            this.label9.TabIndex = 17;
            this.label9.Text = "Cost Per Day :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(27, 245);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 25);
            this.label8.TabIndex = 16;
            this.label8.Text = "Year of Production :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(28, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(165, 25);
            this.label7.TabIndex = 15;
            this.label7.Text = "Licence Number :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(27, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 25);
            this.label6.TabIndex = 14;
            this.label6.Text = "Model :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(393, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(306, 32);
            this.label4.TabIndex = 13;
            this.label4.Text = "You Are About To Less";
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.panel5.Controls.Add(this.txtdur);
            this.panel5.Controls.Add(this.btnLess);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Location = new System.Drawing.Point(271, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1132, 729);
            this.panel5.TabIndex = 12;
            // 
            // txtdur
            // 
            this.txtdur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdur.Location = new System.Drawing.Point(476, 240);
            this.txtdur.Name = "txtdur";
            this.txtdur.Size = new System.Drawing.Size(237, 30);
            this.txtdur.TabIndex = 24;
            // 
            // btnLess
            // 
            this.btnLess.BackColor = System.Drawing.Color.DarkCyan;
            this.btnLess.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLess.ForeColor = System.Drawing.Color.Cornsilk;
            this.btnLess.Location = new System.Drawing.Point(459, 356);
            this.btnLess.Name = "btnLess";
            this.btnLess.Size = new System.Drawing.Size(111, 41);
            this.btnLess.TabIndex = 23;
            this.btnLess.Text = "Less";
            this.btnLess.UseVisualStyleBackColor = false;
            this.btnLess.Click += new System.EventHandler(this.btnLess_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(275, 243);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(167, 25);
            this.label11.TabIndex = 22;
            this.label11.Text = "Duration In Days :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(207, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(683, 32);
            this.label12.TabIndex = 21;
            this.label12.Text = "Please Write The Duration You Will Less The Car For";
            // 
            // Lessor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(1366, 668);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.Name = "Lessor";
            this.Text = "Lessor";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Lessor_FormClosing);
            this.Load += new System.EventHandler(this.Lessor_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Report;
        private System.Windows.Forms.Button Choose_Vehicle;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label Picture;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Cost;
        private System.Windows.Forms.Label Type_Vehicle;
        private System.Windows.Forms.ComboBox comcost;
        private System.Windows.Forms.ComboBox comtyper;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtorderno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtinfo;
        private System.Windows.Forms.TextBox txttitle;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Label lbldetails;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtvno;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtloc;
        private System.Windows.Forms.TextBox txtcost;
        private System.Windows.Forms.TextBox txtyear;
        private System.Windows.Forms.TextBox txtlno;
        private System.Windows.Forms.TextBox txtmodel;
        private System.Windows.Forms.Button btnprogress;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtdur;
        private System.Windows.Forms.Button btnLess;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button6;
    }
}