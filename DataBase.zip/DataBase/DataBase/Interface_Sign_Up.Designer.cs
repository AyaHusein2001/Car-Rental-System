﻿
namespace DataBase
{
    partial class Interface_Sign_Up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Phone_No = new System.Windows.Forms.TextBox();
            this.Pass = new System.Windows.Forms.TextBox();
            this.Fname = new System.Windows.Forms.TextBox();
            this.Minit = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.TextBox();
            this.SSN = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.ComboBox();
            this.Sign_Up = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label2.Location = new System.Drawing.Point(383, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Phone Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label3.Location = new System.Drawing.Point(383, 94);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(383, 171);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Fname";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label5.Location = new System.Drawing.Point(524, 171);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Minit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label6.Location = new System.Drawing.Point(624, 171);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "LName";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label7.Location = new System.Drawing.Point(383, 251);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "SSN";
            // 
            // Phone_No
            // 
            this.Phone_No.Location = new System.Drawing.Point(383, 50);
            this.Phone_No.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Phone_No.Name = "Phone_No";
            this.Phone_No.Size = new System.Drawing.Size(113, 22);
            this.Phone_No.TabIndex = 10;
            // 
            // Pass
            // 
            this.Pass.Location = new System.Drawing.Point(383, 122);
            this.Pass.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Pass.Name = "Pass";
            this.Pass.PasswordChar = '*';
            this.Pass.Size = new System.Drawing.Size(113, 22);
            this.Pass.TabIndex = 11;
            this.Pass.UseSystemPasswordChar = true;
            // 
            // Fname
            // 
            this.Fname.Location = new System.Drawing.Point(383, 199);
            this.Fname.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(105, 22);
            this.Fname.TabIndex = 12;
            // 
            // Minit
            // 
            this.Minit.Location = new System.Drawing.Point(496, 199);
            this.Minit.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Minit.Name = "Minit";
            this.Minit.Size = new System.Drawing.Size(104, 22);
            this.Minit.TabIndex = 13;
            // 
            // LName
            // 
            this.LName.Location = new System.Drawing.Point(608, 199);
            this.LName.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(105, 22);
            this.LName.TabIndex = 14;
            // 
            // SSN
            // 
            this.SSN.Location = new System.Drawing.Point(383, 281);
            this.SSN.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.SSN.Name = "SSN";
            this.SSN.Size = new System.Drawing.Size(113, 22);
            this.SSN.TabIndex = 15;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label9.Location = new System.Drawing.Point(383, 344);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "User";
            // 
            // User
            // 
            this.User.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.User.FormattingEnabled = true;
            this.User.Items.AddRange(new object[] {
            "Renter",
            "Lessor"});
            this.User.Location = new System.Drawing.Point(383, 399);
            this.User.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(137, 24);
            this.User.TabIndex = 20;
            // 
            // Sign_Up
            // 
            this.Sign_Up.Location = new System.Drawing.Point(507, 455);
            this.Sign_Up.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Sign_Up.Name = "Sign_Up";
            this.Sign_Up.Size = new System.Drawing.Size(120, 44);
            this.Sign_Up.TabIndex = 21;
            this.Sign_Up.Text = "Sign Up";
            this.Sign_Up.UseVisualStyleBackColor = true;
            this.Sign_Up.Click += new System.EventHandler(this.Sign_Up_Click);
            // 
            // Interface_Sign_Up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DataBase.Properties.Resources.Background;
            this.ClientSize = new System.Drawing.Size(1164, 644);
            this.Controls.Add(this.Sign_Up);
            this.Controls.Add(this.User);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.SSN);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.Minit);
            this.Controls.Add(this.Fname);
            this.Controls.Add(this.Pass);
            this.Controls.Add(this.Phone_No);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "Interface_Sign_Up";
            this.Text = "Interface_Sign_Up";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Interface_Sign_Up_FormClosing);
            this.Load += new System.EventHandler(this.Interface_Sign_Up_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Phone_No;
        private System.Windows.Forms.TextBox Pass;
        private System.Windows.Forms.TextBox Fname;
        private System.Windows.Forms.TextBox Minit;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.TextBox SSN;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox User;
        private System.Windows.Forms.Button Sign_Up;
    }
}